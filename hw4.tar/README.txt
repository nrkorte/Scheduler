Author: Nicholas Korte


1. Is the Shortest Remaining Time First a non-preemptive Algorithm?
    Yes
2. What are the 5 different states a process can be in scheduling (Look into process state
diagram)?
    New
    Ready
    Running
    Waiting
    Terminated
3. Shortest Job First is like Priority Scheduling with the priority based on ______ of the process?
    CPU Burst Time
4. ________ effect is the primary disadvantage of First Come First Serve Scheduling algorithm.
    Convoy
5. How does Multi Level Feedback queue prevent starvation of processes that waits too long in
lower priority queue?
    It increases the priority of the process

FILES
main.py
    Prints out the turnaround and waiting times of given processes from a file and it also prints their gantt chart